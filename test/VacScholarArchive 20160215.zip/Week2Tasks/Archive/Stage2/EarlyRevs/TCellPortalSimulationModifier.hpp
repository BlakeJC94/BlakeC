/*

Copyright (c) 2005-2015, University of Oxford.
All rights reserved.

University of Oxford means the Chancellor, Masters and Scholars of the
University of Oxford, having an administrative office at Wellington
Square, Oxford OX1 2JD, UK.

This file is part of Chaste.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of the University of Oxford nor the names of its
   contributors may be used to endorse or promote products derived from this
   software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

/*
 *
 *  Chaste tutorial - this page gets automatically changed to a wiki page
 *  DO NOT remove the comments below, and if the code has to be changed in
 *  order to run, please check the comments are still accurate
 *
 *
 */



/*
 * = An example showing how to create a new cell-based simulation modifier and use it in a simulation =
 *
 * == Introduction ==
 *
 * EMPTYLINE
 *
 * In this tutorial, we show how to create a new cell-based simulation modifier
 * and use this in a cell-based simulation. The simulation modifier class
 * hierarchy is used to implement setup, update and finalise methods in cell-based
 * simulations.
 *
 * == 1. Including header files ==
 *
 * As in previous cell-based Chaste tutorials, we begin by including the necessary
 * header file and archiving headers.
 */
#include <cxxtest/TestSuite.h>
#include "CheckpointArchiveTypes.hpp"
#include "AbstractCellBasedTestSuite.hpp"

/* The next header defines a base class for cell-based simulation modifiers.
 * Our new modifier class will inherit from this abstract class. */
#include "AbstractCellBasedSimulationModifier.hpp"
/* The remaining header files define classes that will be used in the cell-based
 * simulation test. We have encountered each of these header files in previous cell-based
 * Chaste tutorials. */
#include "AbstractForce.hpp"
#include "HoneycombMeshGenerator.hpp"
#include "NodesOnlyMesh.hpp"
#include "CellsGenerator.hpp"
#include "StochasticDurationCellCycleModel.hpp"
#include "TransitCellProliferativeType.hpp"
#include "RepulsionForce.hpp"
#include "OffLatticeSimulation.hpp"
#include "SmartPointers.hpp"


/*
 * == Defining the cell-based simulation modifier class ==
 *
 * As an example, let us consider a simulation modifier that, at each simulation
 * time step, calculates each cell's height (y coordinate) in a two-dimensional
 * domain and stores it in in the CellData property as "height". This might be
 * used, for example in cell-based simulations where cell behaviour is dictated
 * through some form of positional information along a tissue axis.
 *
 * Note that usually this code would be separated out into a separate declaration
 * in a .hpp file and definition in a .cpp file.
 * Also, while the abstract simulation modifier class is templated over dimensions,
 * for simplicity we hardcode this concrete modifier class to work in 2D only.
 */
class TCellPortalSimulationModifier : public AbstractCellBasedSimulationModifier<2,2>
{
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & archive, const unsigned int version)
    {
        archive & boost::serialization::base_object<AbstractCellBasedSimulationModifier<2,2> >(*this);
    }

/* The first public method is a default constructor, which simply calls the base
 * constructor. */
public:

    TCellPortalSimulationModifier()
        : AbstractCellBasedSimulationModifier<2,2>()
    {}

    /*
     * The next public method is a destructor, which calls the base destructor.
     */
    ~TCellPortalSimulationModifier()
    {}

    /*
     * Next, we override the {{{UpdateAtEndOfTimeStep()}}} method, which specifies what
     * to do to the simulation at the end of each time step. In this class, we simply
     * call the method {{{UpdateCellData()}}} on the cell population; this method is
     * defined later in the class definition.
     */
    void UpdateAtEndOfTimeStep(AbstractCellPopulation<2,2>& rCellPopulation)
    {
        UpdateCellData(rCellPopulation);
    }

    /*
     * The next overridden method, {{{SetupSolve()}}}, specifies what to do to the
     * simulation before the start of the time loop. In this class, we call
     * {{{UpdateCellData()}}} on the cell population, just as in
     * {{{UpdateAtEndOfTimeStep()}}}. This is needed because otherwise
     * {{{CellData}}} will not have been fully initialised when we enter
     * the main time loop of the simulation.
     */
    void SetupSolve(AbstractCellPopulation<2,2>& rCellPopulation, std::string outputDirectory)
    {

        UpdateCellData(rCellPopulation);
    }

    /*
     * Next, we define the {{{UpdateCellData()}}} method itself. This is a helper
     * method that computes the height (y coordinate) of each cell in the population
     * and stores this in the {{{CellData}}} property.
     */
    void UpdateCellData(AbstractCellPopulation<2,2>& rCellPopulation)
    {
        /*
         * We begin by calling {{{Update()}}} on the cell population, which ensures that
         * it is in a coherent state.
         */
        rCellPopulation.Update();

        /*
         * Next, we iterate over the cell population...
         */
        for (AbstractCellPopulation<2>::Iterator cell_iter = rCellPopulation.Begin();
             cell_iter != rCellPopulation.End();
             ++cell_iter)
        {
            unsigned node_index = this->rCellPopulation->GetLocationIndexUsingCell(*cell_iter);
            Node<2>* p_node = this->rCellPopulation->GetNode(node_index);
            double x_coordinate = p_node->rGetLocation()[0];
            double y_coordinate = p_node->rGetLocation()[1];
                        
            //double cell_x = rCellPopulation.GetLocationOfCellCentre(*cell_iter)[0];
            //double cell_y = rCellPopulation.GetLocationOfCellCentre(*cell_iter)[1];

            //cell_iter->GetCellData()->SetItem("x ord", cell_x);
            //cell_iter->GetCellData()->SetItem("y ord", cell_y);
            
            if (x_coordinate <= -5.0)
            {
                p_node->rGetModifiableLocation()[0] = 5.0;
            }
            //else if (x_coordinate == 5.0)
            //{
            //}
            //else if (y_coordinate == -5.0)
            //{
            //}
            //else if (y_coordinate == 5.0)
            //{
            //}
            
        }
    }

    /*
     * Finally, we must override the {{{OutputSimulationModifierParameters()}}} method, which
     * outputs to file any parameters that are defined in the class. In this class, there are
     * no such parameters to output, so we simply call the method defined on the direct
     * parent class (in this case, the abstract class).
     */
    void OutputSimulationModifierParameters(out_stream& rParamsFile)
    {
        AbstractCellBasedSimulationModifier<2>::OutputSimulationModifierParameters(rParamsFile);
    }
};

/*
 * This concludes the definition of the {{{TCellPortalSimulationModifier}}} class.
 *
 * As mentioned in previous cell-based Chaste tutorials, we need to include the next block
 * of code to be able to archive the simulation modifier object in a cell-based simulation,
 * and to obtain a unique identifier for our new class for when writing results to file.
 *
 * The identifiers for this class are defined together here, since we can only have each
 * #include once in this source file. Normally the first include and export would go in
 * the class's header file, and the second #include and export would go in in the .cpp file.
 */
#include "SerializationExportWrapper.hpp"
CHASTE_CLASS_EXPORT(TCellPortalSimulationModifier)
#include "SerializationExportWrapperForCpp.hpp"
CHASTE_CLASS_EXPORT(TCellPortalSimulationModifier)


